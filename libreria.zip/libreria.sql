-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-03-2024 a las 01:16:11
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `libreria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `autores`
--

CREATE TABLE `autores` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `autores`
--

INSERT INTO `autores` (`id`, `nombre`, `fecha_creacion`, `fecha_actualizacion`) VALUES
(1, 'Antoine de Saint-Exupéry', '2024-03-14 20:08:06', '2024-03-14 20:08:06'),
(2, 'J.K. Rowling', '2024-03-14 20:08:06', '2024-03-14 20:08:06'),
(3, 'Gabriel García Márquez', '2024-03-14 20:08:06', '2024-03-14 20:08:06'),
(4, 'George Orwell', '2024-03-14 20:08:06', '2024-03-14 20:08:06'),
(5, 'Miguel de Cervantes', '2024-03-14 20:08:06', '2024-03-14 20:08:06');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `editoriales`
--

CREATE TABLE `editoriales` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `editoriales`
--

INSERT INTO `editoriales` (`id`, `nombre`, `fecha_creacion`, `fecha_actualizacion`) VALUES
(1, 'Salamandra', '2024-03-14 20:48:17', '2024-03-14 20:48:17'),
(2, 'Sudamericana', '2024-03-14 20:48:17', '2024-03-14 20:48:17'),
(3, 'Seix Barral', '2024-03-14 20:48:17', '2024-03-14 20:48:17'),
(4, 'Secker & Warburg', '2024-03-14 20:48:17', '2024-03-14 20:48:17'),
(5, 'Francisco de R.', '2024-03-14 20:48:17', '2024-03-14 22:16:24');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `generos`
--

CREATE TABLE `generos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `generos`
--

INSERT INTO `generos` (`id`, `nombre`, `fecha_creacion`, `fecha_actualizacion`) VALUES
(1, 'Ficción', '2024-03-14 20:51:08', '2024-03-14 20:51:08'),
(2, 'Fantasía', '2024-03-14 20:51:08', '2024-03-14 20:51:08'),
(3, 'Realismo mágico', '2024-03-14 20:51:08', '2024-03-14 20:51:08'),
(4, 'Distopía', '2024-03-14 20:51:08', '2024-03-14 20:51:08'),
(5, 'Novela', '2024-03-14 20:51:08', '2024-03-14 20:51:08'),
(11, 'Didáctico', '2024-03-14 21:54:10', '2024-03-14 21:54:10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libros`
--

CREATE TABLE `libros` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `anno_publicacion` int(11) DEFAULT NULL,
  `autor_id` int(11) DEFAULT NULL,
  `genero_id` int(11) DEFAULT NULL,
  `editorial_id` int(11) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `libros`
--

INSERT INTO `libros` (`id`, `titulo`, `anno_publicacion`, `autor_id`, `genero_id`, `editorial_id`, `fecha_creacion`, `fecha_actualizacion`) VALUES
(1, 'El principito', 1943, 1, 1, 1, '2024-03-14 20:55:48', '2024-03-14 20:55:48'),
(2, 'Harry Potter', 1997, 2, 2, 2, '2024-03-14 20:55:48', '2024-03-14 20:55:48'),
(3, 'Cien años de soledad', 1967, 3, 3, 3, '2024-03-14 20:55:48', '2024-03-14 20:55:48'),
(4, '1984', 1949, 4, 4, 4, '2024-03-14 20:55:48', '2024-03-14 20:55:48'),
(5, 'Don Quijote de la Mancha', 1605, 5, 5, 5, '2024-03-14 20:55:48', '2024-03-14 20:55:48');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reseñas`
--

CREATE TABLE `reseñas` (
  `id` int(11) NOT NULL,
  `contenido` text DEFAULT NULL,
  `libro_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reseñas`
--

INSERT INTO `reseñas` (`id`, `contenido`, `libro_id`, `usuario_id`, `fecha_creacion`, `fecha_actualizacion`) VALUES
(11, 'Excelente libro.', 1, 1, '2024-03-14 21:03:35', '2024-03-14 21:03:35'),
(12, 'Obra maestra.', 2, 2, '2024-03-14 21:03:35', '2024-03-14 21:03:35'),
(13, 'Lectura fascinante.', 3, 3, '2024-03-14 21:03:35', '2024-03-14 21:03:35'),
(14, 'Interesante.', 4, 4, '2024-03-14 21:03:35', '2024-03-14 21:03:35'),
(15, 'Perdurará por siempre', 5, 5, '2024-03-14 21:03:35', '2024-03-14 22:25:57');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `fecha_creacion`, `fecha_actualizacion`) VALUES
(1, 'Juan', '2024-03-14 21:01:47', '2024-03-14 21:01:47'),
(2, 'María', '2024-03-14 21:01:47', '2024-03-14 21:01:47'),
(3, 'Pedro', '2024-03-14 21:01:47', '2024-03-14 21:01:47'),
(4, 'Ana', '2024-03-14 21:01:47', '2024-03-14 21:01:47'),
(5, 'Luis', '2024-03-14 21:01:47', '2024-03-14 21:01:47'),
(6, 'Samuel', '2024-03-14 22:57:44', '2024-03-14 22:57:44');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `autores`
--
ALTER TABLE `autores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `editoriales`
--
ALTER TABLE `editoriales`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `generos`
--
ALTER TABLE `generos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`id`),
  ADD KEY `autor_id` (`autor_id`),
  ADD KEY `genero_id` (`genero_id`),
  ADD KEY `editorial_id` (`editorial_id`);

--
-- Indices de la tabla `reseñas`
--
ALTER TABLE `reseñas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `libro_id` (`libro_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `autores`
--
ALTER TABLE `autores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `editoriales`
--
ALTER TABLE `editoriales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `generos`
--
ALTER TABLE `generos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `libros`
--
ALTER TABLE `libros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `reseñas`
--
ALTER TABLE `reseñas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `libros`
--
ALTER TABLE `libros`
  ADD CONSTRAINT `libros_ibfk_1` FOREIGN KEY (`autor_id`) REFERENCES `autores` (`id`),
  ADD CONSTRAINT `libros_ibfk_2` FOREIGN KEY (`genero_id`) REFERENCES `generos` (`id`),
  ADD CONSTRAINT `libros_ibfk_3` FOREIGN KEY (`editorial_id`) REFERENCES `editoriales` (`id`);

--
-- Filtros para la tabla `reseñas`
--
ALTER TABLE `reseñas`
  ADD CONSTRAINT `reseñas_ibfk_1` FOREIGN KEY (`libro_id`) REFERENCES `libros` (`id`),
  ADD CONSTRAINT `reseñas_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
